<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20200104225135_add_column_is_default_to_categories_and_places_table extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'postgresql', 'Migration can only be executed safely on \'postgresql\'.');

        $this->addSql('ALTER TABLE categories ADD is_default BOOLEAN DEFAULT \'false\' NOT NULL');
        $this->addSql('ALTER TABLE categories ALTER description SET DEFAULT \'general\'');
        $this->addSql('ALTER TABLE places ADD is_default BOOLEAN DEFAULT \'false\' NOT NULL');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'postgresql', 'Migration can only be executed safely on \'postgresql\'.');

        $this->addSql('ALTER TABLE places DROP is_default');
        $this->addSql('ALTER TABLE categories DROP is_default');
        $this->addSql('ALTER TABLE categories ALTER description DROP DEFAULT');
    }
}
