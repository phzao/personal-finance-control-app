<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/api/v1/categories' => [
            [['_route' => 'app_category_save', '_controller' => 'App\\Controller\\CategoryController::save'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_category_list', '_controller' => 'App\\Controller\\CategoryController::list'], null, ['GET' => 0], null, false, false, null],
        ],
        '/api/v1/credit-cards' => [
            [['_route' => 'app_creditcard_save', '_controller' => 'App\\Controller\\CreditCardController::save'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_creditcard_list', '_controller' => 'App\\Controller\\CreditCardController::list'], null, ['GET' => 0], null, false, false, null],
        ],
        '/api/v1/earns' => [
            [['_route' => 'app_earn_save', '_controller' => 'App\\Controller\\EarnController::save'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_earn_list', '_controller' => 'App\\Controller\\EarnController::list'], null, ['GET' => 0], null, false, false, null],
        ],
        '/api/v1/expenses' => [
            [['_route' => 'app_expense_save', '_controller' => 'App\\Controller\\ExpenseController::save'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_expense_list', '_controller' => 'App\\Controller\\ExpenseController::list'], null, ['GET' => 0], null, false, false, null],
        ],
        '/oauth-authenticate' => [[['_route' => 'connect_google', '_controller' => 'App\\Controller\\GoogleController::connectAction'], null, null, null, false, false, null]],
        '/connect/google/check' => [[['_route' => 'connect_google_check', '_controller' => 'App\\Controller\\GoogleController::connectCheckAction'], null, null, null, false, false, null]],
        '/api/v1/places' => [
            [['_route' => 'app_place_save', '_controller' => 'App\\Controller\\PlaceController::save'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_place_list', '_controller' => 'App\\Controller\\PlaceController::list'], null, ['GET' => 0], null, false, false, null],
        ],
        '/register' => [[['_route' => 'app_register_save', '_controller' => 'App\\Controller\\RegisterController::save'], null, ['POST' => 0], null, false, false, null]],
        '/authenticate-demo' => [[['_route' => 'app_register_savedemo', '_controller' => 'App\\Controller\\RegisterController::saveDemo'], null, ['POST' => 0], null, false, false, null]],
        '/authenticate' => [[['_route' => 'app_register_login', '_controller' => 'App\\Controller\\RegisterController::login'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/users/me' => [[['_route' => 'app_user_show', '_controller' => 'App\\Controller\\UserController::show'], null, ['GET' => 0], null, false, false, null]],
        '/api/v1/users' => [[['_route' => 'app_user_update', '_controller' => 'App\\Controller\\UserController::update'], null, ['PUT' => 0], null, false, false, null]],
        '/api/v1/v1/users' => [[['_route' => 'api_users_list_item', '_controller' => 'UserController', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_item_operation_name' => 'list'], null, ['GET' => 0], null, false, false, null]],
        '/api/v1/register' => [[['_route' => 'api_users_register_item', '_controller' => 'RegisterController', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_item_operation_name' => 'register'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/api/v1(?'
                    .'|/(?'
                        .'|c(?'
                            .'|ategories/([^/]++)(?'
                                .'|(*:46)'
                                .'|/(?'
                                    .'|status/([^/]++)(*:72)'
                                    .'|default(*:86)'
                                .')'
                                .'|(*:94)'
                            .')'
                            .'|redit\\-cards/([^/]++)(?'
                                .'|(*:126)'
                                .'|/(?'
                                    .'|status/([^/]++)(*:153)'
                                    .'|default(*:168)'
                                .')'
                                .'|(*:177)'
                            .')'
                        .')'
                        .'|e(?'
                            .'|arns/([^/]++)(?'
                                .'|(*:207)'
                                .'|/confirm(*:223)'
                                .'|(*:231)'
                            .')'
                            .'|xpenses/([^/]++)(?'
                                .'|(*:259)'
                            .')'
                        .')'
                        .'|places/([^/]++)(?'
                            .'|(*:287)'
                            .'|/(?'
                                .'|default(*:306)'
                                .'|status/([^/]++)(*:329)'
                            .')'
                            .'|(*:338)'
                        .')'
                        .'|users/my\\-status\\-to/([^/]++)(*:376)'
                    .')'
                    .'|(?:/(index)(?:\\.([^/]++))?)?(*:413)'
                    .'|/(?'
                        .'|docs(?:\\.([^/]++))?(*:444)'
                        .'|c(?'
                            .'|ontexts/(.+)(?:\\.([^/]++))?(*:483)'
                            .'|ategories(?'
                                .'|(?:\\.([^/]++))?(?'
                                    .'|(*:521)'
                                .')'
                                .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                    .'|(*:559)'
                                .')'
                            .')'
                        .')'
                        .'|places(?'
                            .'|(?:\\.([^/]++))?(?'
                                .'|(*:597)'
                            .')'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:635)'
                            .')'
                        .')'
                        .'|users(?:\\.([^/]++))?(?'
                            .'|(*:668)'
                        .')'
                        .'|expenses(?'
                            .'|(?:\\.([^/]++))?(?'
                                .'|(*:706)'
                            .')'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:744)'
                            .')'
                        .')'
                    .')'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        46 => [
            [['_route' => 'app_category_show', '_controller' => 'App\\Controller\\CategoryController::show'], ['uuid'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_category_update', '_controller' => 'App\\Controller\\CategoryController::update'], ['uuid'], ['PUT' => 0], null, false, true, null],
        ],
        72 => [[['_route' => 'app_category_updatestatus', '_controller' => 'App\\Controller\\CategoryController::updateStatus'], ['uuid', 'status'], ['PUT' => 0], null, false, true, null]],
        86 => [[['_route' => 'app_category_updatedefaultstatus', '_controller' => 'App\\Controller\\CategoryController::updateDefaultStatus'], ['uuid'], ['PUT' => 0], null, false, false, null]],
        94 => [[['_route' => 'app_category_delete', '_controller' => 'App\\Controller\\CategoryController::delete'], ['uuid'], ['DELETE' => 0], null, false, true, null]],
        126 => [
            [['_route' => 'app_creditcard_show', '_controller' => 'App\\Controller\\CreditCardController::show'], ['uuid'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_creditcard_update', '_controller' => 'App\\Controller\\CreditCardController::update'], ['uuid'], ['PUT' => 0], null, false, true, null],
        ],
        153 => [[['_route' => 'app_creditcard_updatestatus', '_controller' => 'App\\Controller\\CreditCardController::updateStatus'], ['uuid', 'status'], ['PUT' => 0], null, false, true, null]],
        168 => [[['_route' => 'app_creditcard_updatedefaultstatus', '_controller' => 'App\\Controller\\CreditCardController::updateDefaultStatus'], ['uuid'], ['PUT' => 0], null, false, false, null]],
        177 => [[['_route' => 'app_creditcard_delete', '_controller' => 'App\\Controller\\CreditCardController::delete'], ['uuid'], ['DELETE' => 0], null, false, true, null]],
        207 => [[['_route' => 'app_earn_show', '_controller' => 'App\\Controller\\EarnController::show'], ['uuid'], ['GET' => 0], null, false, true, null]],
        223 => [[['_route' => 'app_earn_confirmearn', '_controller' => 'App\\Controller\\EarnController::confirmEarn'], ['uuid'], ['PUT' => 0], null, false, false, null]],
        231 => [
            [['_route' => 'app_earn_update', '_controller' => 'App\\Controller\\EarnController::update'], ['uuid'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_earn_delete', '_controller' => 'App\\Controller\\EarnController::delete'], ['uuid'], ['DELETE' => 0], null, false, true, null],
        ],
        259 => [
            [['_route' => 'app_expense_update', '_controller' => 'App\\Controller\\ExpenseController::update'], ['uuid'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_expense_delete', '_controller' => 'App\\Controller\\ExpenseController::delete'], ['uuid'], ['DELETE' => 0], null, false, true, null],
        ],
        287 => [
            [['_route' => 'app_place_show', '_controller' => 'App\\Controller\\PlaceController::show'], ['uuid'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_place_update', '_controller' => 'App\\Controller\\PlaceController::update'], ['uuid'], ['PUT' => 0], null, false, true, null],
        ],
        306 => [[['_route' => 'app_place_updatedefaultstatus', '_controller' => 'App\\Controller\\PlaceController::updateDefaultStatus'], ['uuid'], ['PUT' => 0], null, false, false, null]],
        329 => [[['_route' => 'app_place_updatestatus', '_controller' => 'App\\Controller\\PlaceController::updateStatus'], ['uuid', 'status'], ['PUT' => 0], null, false, true, null]],
        338 => [[['_route' => 'app_place_delete', '_controller' => 'App\\Controller\\PlaceController::delete'], ['uuid'], ['DELETE' => 0], null, false, true, null]],
        376 => [[['_route' => 'app_user_updatestatus', '_controller' => 'App\\Controller\\UserController::updateStatus'], ['status'], ['PUT' => 0], null, false, true, null]],
        413 => [[['_route' => 'api_entrypoint', '_controller' => 'api_platform.action.entrypoint', '_format' => '', '_api_respond' => 'true', 'index' => 'index'], ['index', '_format'], null, null, false, true, null]],
        444 => [[['_route' => 'api_doc', '_controller' => 'api_platform.action.documentation', '_format' => '', '_api_respond' => 'true'], ['_format'], null, null, false, true, null]],
        483 => [[['_route' => 'api_jsonld_context', '_controller' => 'api_platform.jsonld.action.context', '_format' => 'jsonld', '_api_respond' => 'true'], ['shortName', '_format'], null, null, false, true, null]],
        521 => [
            [['_route' => 'api_categories_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_categories_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        559 => [
            [['_route' => 'api_categories_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_categories_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_categories_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_categories_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        597 => [
            [['_route' => 'api_places_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Place', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_places_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Place', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        635 => [
            [['_route' => 'api_places_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Place', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_places_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Place', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_places_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Place', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_places_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Place', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        668 => [
            [['_route' => 'api_users_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_users_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        706 => [
            [['_route' => 'api_expenses_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Expense', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_expenses_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Expense', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        744 => [
            [['_route' => 'api_expenses_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Expense', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_expenses_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Expense', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_expenses_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Expense', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_expenses_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Expense', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
