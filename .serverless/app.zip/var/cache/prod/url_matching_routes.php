<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/api/v1/categories' => [
            [['_route' => 'app_category_save', '_controller' => 'App\\Controller\\CategoryController::save'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_category_list', '_controller' => 'App\\Controller\\CategoryController::list'], null, ['GET' => 0], null, false, false, null],
        ],
        '/api/v1/credit-cards' => [
            [['_route' => 'app_creditcard_save', '_controller' => 'App\\Controller\\CreditCardController::save'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_creditcard_list', '_controller' => 'App\\Controller\\CreditCardController::list'], null, ['GET' => 0], null, false, false, null],
        ],
        '/api/v1/earns' => [
            [['_route' => 'app_earn_save', '_controller' => 'App\\Controller\\EarnController::save'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_earn_list', '_controller' => 'App\\Controller\\EarnController::list'], null, ['GET' => 0], null, false, false, null],
        ],
        '/api/v1/expenses' => [
            [['_route' => 'app_expense_save', '_controller' => 'App\\Controller\\ExpenseController::save'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_expense_list', '_controller' => 'App\\Controller\\ExpenseController::list'], null, ['GET' => 0], null, false, false, null],
        ],
        '/oauth-authenticate' => [[['_route' => 'connect_google', '_controller' => 'App\\Controller\\GoogleController::connectAction'], null, null, null, false, false, null]],
        '/connect/google/check' => [[['_route' => 'connect_google_check', '_controller' => 'App\\Controller\\GoogleController::connectCheckAction'], null, null, null, false, false, null]],
        '/api/v1/places' => [
            [['_route' => 'app_place_save', '_controller' => 'App\\Controller\\PlaceController::save'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_place_list', '_controller' => 'App\\Controller\\PlaceController::list'], null, ['GET' => 0], null, false, false, null],
        ],
        '/register' => [[['_route' => 'app_register_save', '_controller' => 'App\\Controller\\RegisterController::save'], null, ['POST' => 0], null, false, false, null]],
        '/google-authenticate' => [[['_route' => 'app_register_logingoogle', '_controller' => 'App\\Controller\\RegisterController::loginGoogle'], null, ['POST' => 0], null, false, false, null]],
        '/authenticate-demo' => [[['_route' => 'app_register_savedemo', '_controller' => 'App\\Controller\\RegisterController::saveDemo'], null, ['POST' => 0], null, false, false, null]],
        '/authenticate' => [[['_route' => 'app_register_login', '_controller' => 'App\\Controller\\RegisterController::login'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/users/me' => [[['_route' => 'app_user_show', '_controller' => 'App\\Controller\\UserController::show'], null, ['GET' => 0], null, false, false, null]],
        '/api/v1/users' => [[['_route' => 'app_user_update', '_controller' => 'App\\Controller\\UserController::update'], null, ['PUT' => 0], null, false, false, null]],
        '/api/v1/v1/users' => [[['_route' => 'api_users_list_item', '_controller' => 'UserController', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_item_operation_name' => 'list'], null, ['GET' => 0], null, false, false, null]],
        '/api/v1/register' => [[['_route' => 'api_users_register_item', '_controller' => 'RegisterController', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_item_operation_name' => 'register'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/api/v1(?'
                    .'|/(?'
                        .'|c(?'
                            .'|ategories/([^/]++)(?'
                                .'|(*:46)'
                                .'|/(?'
                                    .'|status/([^/]++)(*:72)'
                                    .'|default(*:86)'
                                .')'
                                .'|(*:94)'
                            .')'
                            .'|redit\\-cards/([^/]++)(?'
                                .'|(*:126)'
                                .'|/(?'
                                    .'|status/([^/]++)(*:153)'
                                    .'|default(*:168)'
                                .')'
                                .'|(*:177)'
                            .')'
                        .')'
                        .'|e(?'
                            .'|arns/([^/]++)(?'
                                .'|(*:207)'
                                .'|/confirm(*:223)'
                                .'|(*:231)'
                            .')'
                            .'|xpenses/(?'
                                .'|([^/]++)(*:259)'
                                .'|paid/([^/]++)(*:280)'
                                .'|([^/]++)(?'
                                    .'|(*:299)'
                                .')'
                            .')'
                        .')'
                        .'|places/([^/]++)(?'
                            .'|(*:328)'
                            .'|/(?'
                                .'|default(*:347)'
                                .'|status/([^/]++)(*:370)'
                            .')'
                            .'|(*:379)'
                        .')'
                        .'|users/my\\-status\\-to/([^/]++)(*:417)'
                    .')'
                    .'|(?:/(index)(?:\\.([^/]++))?)?(*:454)'
                    .'|/(?'
                        .'|docs(?:\\.([^/]++))?(*:485)'
                        .'|c(?'
                            .'|ontexts/(.+)(?:\\.([^/]++))?(*:524)'
                            .'|ategories(?'
                                .'|(?:\\.([^/]++))?(?'
                                    .'|(*:562)'
                                .')'
                                .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                    .'|(*:600)'
                                .')'
                            .')'
                        .')'
                        .'|places(?'
                            .'|(?:\\.([^/]++))?(?'
                                .'|(*:638)'
                            .')'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:676)'
                            .')'
                        .')'
                        .'|users(?:\\.([^/]++))?(?'
                            .'|(*:709)'
                        .')'
                        .'|expenses(?'
                            .'|(?:\\.([^/]++))?(?'
                                .'|(*:747)'
                            .')'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:785)'
                            .')'
                        .')'
                    .')'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        46 => [
            [['_route' => 'app_category_show', '_controller' => 'App\\Controller\\CategoryController::show'], ['uuid'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_category_update', '_controller' => 'App\\Controller\\CategoryController::update'], ['uuid'], ['PUT' => 0], null, false, true, null],
        ],
        72 => [[['_route' => 'app_category_updatestatus', '_controller' => 'App\\Controller\\CategoryController::updateStatus'], ['uuid', 'status'], ['PUT' => 0], null, false, true, null]],
        86 => [[['_route' => 'app_category_updatedefaultstatus', '_controller' => 'App\\Controller\\CategoryController::updateDefaultStatus'], ['uuid'], ['PUT' => 0], null, false, false, null]],
        94 => [[['_route' => 'app_category_delete', '_controller' => 'App\\Controller\\CategoryController::delete'], ['uuid'], ['DELETE' => 0], null, false, true, null]],
        126 => [
            [['_route' => 'app_creditcard_show', '_controller' => 'App\\Controller\\CreditCardController::show'], ['uuid'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_creditcard_update', '_controller' => 'App\\Controller\\CreditCardController::update'], ['uuid'], ['PUT' => 0], null, false, true, null],
        ],
        153 => [[['_route' => 'app_creditcard_updatestatus', '_controller' => 'App\\Controller\\CreditCardController::updateStatus'], ['uuid', 'status'], ['PUT' => 0], null, false, true, null]],
        168 => [[['_route' => 'app_creditcard_updatedefaultstatus', '_controller' => 'App\\Controller\\CreditCardController::updateDefaultStatus'], ['uuid'], ['PUT' => 0], null, false, false, null]],
        177 => [[['_route' => 'app_creditcard_delete', '_controller' => 'App\\Controller\\CreditCardController::delete'], ['uuid'], ['DELETE' => 0], null, false, true, null]],
        207 => [[['_route' => 'app_earn_show', '_controller' => 'App\\Controller\\EarnController::show'], ['uuid'], ['GET' => 0], null, false, true, null]],
        223 => [[['_route' => 'app_earn_confirmearn', '_controller' => 'App\\Controller\\EarnController::confirmEarn'], ['uuid'], ['PUT' => 0], null, false, false, null]],
        231 => [
            [['_route' => 'app_earn_update', '_controller' => 'App\\Controller\\EarnController::update'], ['uuid'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_earn_delete', '_controller' => 'App\\Controller\\EarnController::delete'], ['uuid'], ['DELETE' => 0], null, false, true, null],
        ],
        259 => [[['_route' => 'app_expense_update', '_controller' => 'App\\Controller\\ExpenseController::update'], ['uuid'], ['PUT' => 0], null, false, true, null]],
        280 => [[['_route' => 'app_expense_paid', '_controller' => 'App\\Controller\\ExpenseController::paid'], ['uuid'], ['PUT' => 0], null, false, true, null]],
        299 => [
            [['_route' => 'app_expense_delete', '_controller' => 'App\\Controller\\ExpenseController::delete'], ['uuid'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'app_expense_show', '_controller' => 'App\\Controller\\ExpenseController::show'], ['uuid'], ['GET' => 0], null, false, true, null],
        ],
        328 => [
            [['_route' => 'app_place_show', '_controller' => 'App\\Controller\\PlaceController::show'], ['uuid'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_place_update', '_controller' => 'App\\Controller\\PlaceController::update'], ['uuid'], ['PUT' => 0], null, false, true, null],
        ],
        347 => [[['_route' => 'app_place_updatedefaultstatus', '_controller' => 'App\\Controller\\PlaceController::updateDefaultStatus'], ['uuid'], ['PUT' => 0], null, false, false, null]],
        370 => [[['_route' => 'app_place_updatestatus', '_controller' => 'App\\Controller\\PlaceController::updateStatus'], ['uuid', 'status'], ['PUT' => 0], null, false, true, null]],
        379 => [[['_route' => 'app_place_delete', '_controller' => 'App\\Controller\\PlaceController::delete'], ['uuid'], ['DELETE' => 0], null, false, true, null]],
        417 => [[['_route' => 'app_user_updatestatus', '_controller' => 'App\\Controller\\UserController::updateStatus'], ['status'], ['PUT' => 0], null, false, true, null]],
        454 => [[['_route' => 'api_entrypoint', '_controller' => 'api_platform.action.entrypoint', '_format' => '', '_api_respond' => 'true', 'index' => 'index'], ['index', '_format'], null, null, false, true, null]],
        485 => [[['_route' => 'api_doc', '_controller' => 'api_platform.action.documentation', '_format' => '', '_api_respond' => 'true'], ['_format'], null, null, false, true, null]],
        524 => [[['_route' => 'api_jsonld_context', '_controller' => 'api_platform.jsonld.action.context', '_format' => 'jsonld', '_api_respond' => 'true'], ['shortName', '_format'], null, null, false, true, null]],
        562 => [
            [['_route' => 'api_categories_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_categories_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        600 => [
            [['_route' => 'api_categories_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_categories_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_categories_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_categories_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Category', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        638 => [
            [['_route' => 'api_places_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Place', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_places_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Place', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        676 => [
            [['_route' => 'api_places_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Place', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_places_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Place', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_places_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Place', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_places_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Place', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        709 => [
            [['_route' => 'api_users_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_users_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        747 => [
            [['_route' => 'api_expenses_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Expense', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_expenses_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Expense', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        785 => [
            [['_route' => 'api_expenses_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Expense', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_expenses_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Expense', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_expenses_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Expense', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_expenses_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Expense', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
